/* Hello World Program */

public class HelloWorld {

	public static void main(String[] args) {
		
		// print the text "Hello World" to the console
		System.out.println("Hello World from Java");
		
	}

}
