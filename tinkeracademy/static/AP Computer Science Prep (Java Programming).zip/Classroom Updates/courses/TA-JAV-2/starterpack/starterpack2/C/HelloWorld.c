/* Hello World Program */

#include <stdio.h>

int main(int argc, const char * argv[]) {

	// print the text "Hello World" and a new line character to the console
	printf("Hello World from C\n");

	// return the value of 0 to indicate this program was successfully called
	return 0;
}
