package com.tinkeracademy.workbook;
 
public class Worksheet17 {
    
    public static void main(String[] args) {
        
        
        
    }
}
