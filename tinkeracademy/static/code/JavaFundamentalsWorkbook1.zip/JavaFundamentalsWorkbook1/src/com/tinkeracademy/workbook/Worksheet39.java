package com.tinkeracademy.workbook;
 
public class Worksheet39 {
    public static void main(String[] args) {
       
       
              
       
       
      
       
    }
}
