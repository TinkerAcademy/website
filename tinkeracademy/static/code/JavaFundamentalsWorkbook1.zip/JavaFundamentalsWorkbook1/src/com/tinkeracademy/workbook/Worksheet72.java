package com.tinkeracademy.workbook;
 
public class Worksheet72 {
    
    public static void main(String[] args) {
        String[] lowercaseAlphabets = {
                "c", "o", "k", "i", "e", "s"
        };
        String[] uppercaseAlphabets = {
                "C", "O", "K", "I", "E", "S"
        };
        
        
        
        
        
        
        
        
        
        
        
    }
}
