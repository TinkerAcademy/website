package com.tinkeracademy.workbook;
 
public class Worksheet41 {
    public static void main(String[] args) {
       
       
       
    }
}
