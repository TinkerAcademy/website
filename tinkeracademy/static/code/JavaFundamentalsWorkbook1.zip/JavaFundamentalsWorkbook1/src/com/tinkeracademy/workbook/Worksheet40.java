package com.tinkeracademy.workbook;
 
public class Worksheet40 {
    public static void main(String[] args) {
       
       
       
    }
}
