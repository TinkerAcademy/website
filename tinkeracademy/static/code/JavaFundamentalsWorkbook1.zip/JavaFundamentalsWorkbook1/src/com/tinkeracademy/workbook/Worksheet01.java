package com.tinkeracademy.workbook;
 
public class Worksheet01 {
    public static void main(String[] args) {
       
    }
}
