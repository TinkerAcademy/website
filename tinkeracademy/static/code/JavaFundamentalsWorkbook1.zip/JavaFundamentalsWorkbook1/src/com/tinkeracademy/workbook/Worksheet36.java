package com.tinkeracademy.workbook;
 
public class Worksheet36 {
    public static void main(String[] args) {
       
              
       
       
    }
}
