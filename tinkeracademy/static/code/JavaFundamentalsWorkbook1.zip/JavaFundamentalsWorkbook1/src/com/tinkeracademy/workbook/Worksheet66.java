package com.tinkeracademy.workbook;
 
public class Worksheet66 {
    
    public static void main(String[] args) {
        
        
        
        
        
        
        
        
        
        
        
       
       
        
     }
}
