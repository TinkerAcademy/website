package com.tinkeracademy.workbook;
 
public class Worksheet02 {
    public static void main(String[] args) {
        
    }
}
