package com.tinkeracademy.workbook;
 
public class Worksheet03 {
    
    public static void main(String[] args) {
        
        
     }
}
