package com.tinkeracademy.workbook;
 
public class Worksheet52 {
    public static void main(String[] args) {
       
       
       
       
       
       
    }
}
