package com.tinkeracademy.workbook;
 
public class Worksheet34 {
    public static void main(String[] args) {
       
              
       
       
    }
}
