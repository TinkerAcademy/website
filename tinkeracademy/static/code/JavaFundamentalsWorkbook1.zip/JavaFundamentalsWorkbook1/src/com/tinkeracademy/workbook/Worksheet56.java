package com.tinkeracademy.workbook;
 
public class Worksheet56 {
    public static void main(String[] args) {
       
       
              
       
    	
    	
    	
       
       
    }
}
