package com.tinkeracademy.workbook;
 
public class Worksheet20 {
    
    public static void main(String[] args) {
        
        
        
    }
}
