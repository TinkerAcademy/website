package com.tinkeracademy.workbook;
 
public class Worksheet46 {
    public static void main(String[] args) {
      
       
       
    }
}
