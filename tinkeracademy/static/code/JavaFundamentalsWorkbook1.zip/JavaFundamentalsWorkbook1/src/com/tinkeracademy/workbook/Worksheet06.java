package com.tinkeracademy.workbook;
 
public class Worksheet06 {
    public static void main(String[] args) {
       
       
    }
}

