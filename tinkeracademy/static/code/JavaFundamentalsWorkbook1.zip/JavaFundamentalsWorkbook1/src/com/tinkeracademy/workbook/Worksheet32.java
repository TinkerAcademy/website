package com.tinkeracademy.workbook;
 
public class Worksheet32 {
    public static void main(String[] args) {
       
              
       
       
    }
}
