package com.tinkeracademy.workbook;
 
import java.util.Arrays;

public class Worksheet69 {
    public static void main(String[] args) {
       
       
       
       
       
       
       
       
       
       
       
       
    }
}
