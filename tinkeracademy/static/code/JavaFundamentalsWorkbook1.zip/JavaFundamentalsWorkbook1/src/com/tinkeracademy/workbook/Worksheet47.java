package com.tinkeracademy.workbook;
 
public class Worksheet47 {
    public static void main(String[] args) {
       
       
       
    }
}
