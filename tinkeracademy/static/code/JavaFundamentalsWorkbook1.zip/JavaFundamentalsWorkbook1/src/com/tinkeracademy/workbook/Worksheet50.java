package com.tinkeracademy.workbook;
 
public class Worksheet50 {
    public static void main(String[] args) {
       
       
         
    }
}
