package com.tinkeracademy.workbook;
 
public class Worksheet59 {
    public static void main(String[] args) {
       
       
       
    }
}
