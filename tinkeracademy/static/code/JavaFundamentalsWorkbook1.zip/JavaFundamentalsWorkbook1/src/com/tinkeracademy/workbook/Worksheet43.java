package com.tinkeracademy.workbook;
 
public class Worksheet43 {
    public static void main(String[] args) {
       
       
       
    }
}
