package com.tinkeracademy.workbook;
 
public class Worksheet07 {
    public static void main(String[] args) {
       
       
       
    }
}
