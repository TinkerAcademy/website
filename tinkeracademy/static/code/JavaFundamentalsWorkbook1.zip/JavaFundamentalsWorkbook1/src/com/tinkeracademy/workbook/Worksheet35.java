package com.tinkeracademy.workbook;
 
public class Worksheet35 {
    public static void main(String[] args) {
       
              
       
    }
}
