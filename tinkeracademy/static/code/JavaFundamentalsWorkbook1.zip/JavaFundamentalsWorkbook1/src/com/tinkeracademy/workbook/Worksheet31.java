package com.tinkeracademy.workbook;
 
public class Worksheet31 {
    public static void main(String[] args) {
       
              
       
    }
}
