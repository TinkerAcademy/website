package com.tinkeracademy.workbook;
 
public class Worksheet71 {
    public static void main(String[] args) {
       
       
       
    }
}
