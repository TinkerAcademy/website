package com.tinkeracademy.workbook;
 
public class Worksheet67 {
    
    public static void main(String[] args) {
        
        
        
        





     }
}
