package com.tinkeracademy.workbook;
 
public class Worksheet25 {
    
    public static void main(String[] args) {
        
        
        
        
        
        
        
    }
}
